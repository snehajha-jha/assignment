export interface Product {
  id: number;
  image: string;
  name: string;
  price: number;
  RAM: string;
  SSD: string;
  HDD: string;
  ScreenSize: string;
  OS: string;
}