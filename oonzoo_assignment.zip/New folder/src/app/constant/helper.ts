export const sizes = [
    { id: 1, label: '11 inches - 11.9 inches'  },
    { id: 2, label: '12 inches - 12.9 inches' },
    { id: 3, label: '13 inches - 13.9 inches' },
    { id: 4, label: '14 inches - 14.9 inches' },
    { id: 5, label: '15 inches - 15.9 inches' },
    { id: 6, label: '16 inches - 17.9 inches' },
    { id: 7, label: '18 inches - 20 inches' },

  ];
  export const os=[
    {id:1, label:'Windows 8'},
    {id:2,label:'Windows 9'},
    {id:3,label:'Windows 10'},
    {id:4,label:'Windows 11'},
    {id:5,label:'Windows 12'},
    {id:6,label:'Linux'},
    {id:7,label:'MacOS' },
  ]
  export const Ram=[
    {id:1, label:'8 GB'},
    {id:2,label:'16 GB' },
    {id:3,label:'32 GB'},
    {id:4,label:'64 GB'},
  ]
  export const SSD=[
    {id:1, label:'8 GB'},
    {id:2,label:'16 GB' },
    {id:3,label:'32 GB'},
    {id:4,label:'64 GB'},
    {id:5,label:'128 GB'},
    {id:6,label:'256 GB'},
    {id:7,label:'512 GB'},
  ]
  